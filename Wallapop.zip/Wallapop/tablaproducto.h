#ifndef _TABLAPRODUCTO_H_
#define _TABLAPRODUCTO_H_
#include <QModelIndex>
#include <QAbstractTableModel>
#include <QTableView>
#include "producto.h"
#include <QVariant>
#include <QDebug>
class TablaProducto: public QAbstractTableModel{
Q_OBJECT
public:
	TablaProducto(QVector <Producto*> *);
	QVector <Producto*> *listaProductos;
	int columnCount(const QModelIndex & = QModelIndex())const;
	int rowCount(const QModelIndex & = QModelIndex())const;
	void actualizaDatos();
	QVariant data(const QModelIndex &index, int role = Qt::DisplayRole) const;
	QVariant headerData(int section, Qt::Orientation orientation,int role=Qt::DisplayRole)const;
	
	
};

#endif

