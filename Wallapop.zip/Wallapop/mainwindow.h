
#ifndef MAINWINDOW_H
#define MAINWINDOW_H
#include "ui_mainwindow.h"

#include <QVector>
#include <QDialog>
#include <QHBoxLayout>
#include "usuario.h"
#include "tablausuario.h"
#include "tablaproducto.h"
#include "tablacategoria.h"
#include "productocontroller.h"
#include "categoriacontroller.h"
#include "usuariocontroller.h"
#include <QModelIndex>
#include <QAbstractTableModel>
#include <QTableView>
#include <QtSql/QSqlQuery>
#include <QtSql/QSqlDatabase>
#include "producto.h"
#include "categoria.h"
#include <QAction>
#include <QJsonObject>
#include <QJsonArray>
#include <QJsonDocument>
#include <QtNetwork/QNetworkRequest>
#include <QtNetwork/QNetworkReply>
#include <QtNetwork/QNetworkAccessManager>
#include <QByteArray>
#include <QStringList>
#include <QList>
#include "dusuarioeditar.h"

class MainWindow : public QMainWindow, public Ui::MainWindow {
Q_OBJECT

public:
	MainWindow(QWidget *parent = NULL);
	Usuario *usuario;
	QTableView *tablaProductos;
	TablaProducto *modeloTablaProductos;
	ProductoController *pController;
	QVector <Producto*> listaProductos;
	void crearTablaProductos();
	
	QTableView *tablaCategorias;
	TablaCategoria *modeloTablaCategorias;
	CategoriaController *cController;
	QVector <Categoria*> listaCategorias;
	void crearTablaCategorias();
	
	QTableView *tablaUsuarios;
	TablaUsuario *modeloTablaUsuarios;
	UsuarioController *uController;
	QVector <Usuario*> listaUsuarios;
	void crearTablaUsuarios();
	
	DUsuarioEditar *dUsuarioEditar;
public slots:
	void slotDialogoUsuarioFinalizado(int);
	void slotDialogoUsuario(const QModelIndex &);
	void slotPeticionProductoTerminada();
	void slotPeticionCategoriaTerminada();
	void slotPeticionUsuarioTerminada();
	
};

#endif 
