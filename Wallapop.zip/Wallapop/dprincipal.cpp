
#include "dprincipal.h"
#include <QDebug>
#include "database.h"
DPrincipal::DPrincipal(QString nombre,QWidget *parent): QDialog(parent){
		setupUi(this);
	nombreSesion->setText(nombre);
	
}

DPrincipal::DPrincipal(Usuario *usuarioPasado,QWidget *parent): QDialog(parent){
		setupUi(this);
		
	usuario = usuarioPasado;

	QString cadena=usuario->mail;

	nombreSesion->setText(cadena);
	
	modeloTablaProductos=NULL;
	tablaProductos = new QTableView();
	pController = new ProductoController();
	connect(pController,SIGNAL(peticionTerminada()),
		this,SLOT(slotPeticionProductoTerminada()));
	pController->selectAll();
	
	modeloTablaCategorias=NULL;
	tablaCategorias = new QTableView();
	cController = new CategoriaController();
	connect(cController,SIGNAL(peticionTerminada()),
		this,SLOT(slotPeticionCategoriaTerminada()));
	cController->selectAll();
	
	modeloTablaUsuarios=NULL;
	tablaUsuarios = new QTableView();
	uController = new UsuarioController();
	connect(uController,SIGNAL(peticionTerminada()),
		this,SLOT(slotPeticionUsuarioTerminada()));
	uController->selectAll();
	
	tabProductos->clear();
	
	
	
	
	
	
	
}
void DPrincipal::slotPeticionProductoTerminada(){
	
	pController->getProductos(&listaProductos);
	crearTablaProductos();


}

void DPrincipal::crearTablaProductos(){

	modeloTablaProductos = new TablaProducto(&listaProductos);
	tablaProductos->setModel(modeloTablaProductos);
	
	tabProductos->addTab(tablaProductos,"Productos");
	


}

void DPrincipal::slotPeticionCategoriaTerminada(){
	
	cController->getCategorias(&listaCategorias);
	crearTablaCategorias();

}

void DPrincipal::crearTablaCategorias(){

	modeloTablaCategorias = new TablaCategoria(&listaCategorias);
	tablaCategorias->setModel(modeloTablaCategorias);
	
	tabProductos->addTab(tablaCategorias,"Categorias");
	
}

void DPrincipal::slotPeticionUsuarioTerminada(){
	
	uController->getUsuarios(&listaUsuarios);
	qDebug()<<listaUsuarios.size();
	crearTablaUsuarios();

}

void DPrincipal::crearTablaUsuarios(){

	modeloTablaUsuarios = new TablaUsuario(&listaUsuarios);
	tablaUsuarios->setModel(modeloTablaUsuarios);
	
	tabProductos->addTab(tablaUsuarios,"Usuarios");
	
}

void DPrincipal::slotEjemplo(){

}

