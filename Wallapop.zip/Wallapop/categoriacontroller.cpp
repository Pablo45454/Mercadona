#include "categoriacontroller.h"

CategoriaController::CategoriaController()
{

}

void CategoriaController::selectAll(){
qDebug()<<"Llego a selectall";
	QJsonObject jsonObject;
	jsonObject.insert("jsonrpc", "2.0");
        jsonObject.insert("method", "call");
        jsonObject.insert("id", 970248153);
        QJsonObject params;
        params.insert("service", "object");
        params.insert("method", "execute");
        QJsonArray args;
        args.append("salespop");
        args.append(2);
        args.append("1234");
        args.append("salespop.category");
        args.append("search_read");
        QJsonArray emptyArray;
        args.append(emptyArray);
        QJsonArray fields;
        fields.append("id");
        fields.append("name"); 
        args.append(fields);
        params.insert("args", args);
        jsonObject.insert("params", params);
        
        QByteArray postData = QJsonDocument(jsonObject).toJson();
	QNetworkAccessManager *manager = new QNetworkAccessManager();
	connect(manager,SIGNAL(finished(QNetworkReply *)),
		this,SLOT(slotPeticion(QNetworkReply *)));
	QNetworkRequest request;
	request.setUrl(QUrl("http://192.168.8.13:8069/jsonrpc"));
	request.setRawHeader(QByteArray("Content-Type"), QByteArray("application/json"));
	QNetworkReply *reply = manager->post(request, postData);
	
	



}
void CategoriaController::slotPeticion(QNetworkReply* reply){
 if (reply->error() != QNetworkReply::NoError) {
            qDebug() << "Error: " << reply->errorString();
        } else  if (reply->isFinished()){
        	
            responseData =QJsonDocument::fromJson(reply->readAll());
            qDebug()<<responseData;
            emit peticionTerminada();
            
               
        }
        reply->deleteLater();

}

void CategoriaController::getCategorias(QVector<Categoria*> *listaCategorias){
		for(int i = 0; i<listaCategorias->size();i++){
			delete listaCategorias->at(i);
		
		}
		listaCategorias->clear();
		qDebug()<<"tamaño despues del clear:"<<listaCategorias->size();
 		QJsonObject jsonResponse = responseData.object();
            
            if(jsonResponse.contains("result")){
            	QJsonArray result = jsonResponse["result"].toArray();
            	qDebug()<<"result size:"<<result.size();
            	for(int i = 0; i < result.size(); i++){
            		QJsonObject partner = result[i].toObject();
            		
            		Categoria *categoria = new Categoria(partner["id"].toInt(),
            		partner["name"].toString());
            		
            		listaCategorias->append(categoria);
            	}
            	qDebug()<<"tamaño despues de la peticion"<<listaCategorias->size();
            	
            
            }


}
