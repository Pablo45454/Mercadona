
#include "dlogin.h"
#include <QDebug>
#include "dregistro.h"
DLogin::DLogin(QWidget *parent): QDialog(parent){
		setupUi(this);
	dRegistro = NULL;
	dPrincipal = NULL;
	mainWindow = NULL;
	usuario = new Usuario(34, "Pablo", "pABLO123", "+34 543453", "ABC1123", "pablogarrido@gmail.com");
	connect(bRegistro,SIGNAL(clicked()),
		this,SLOT(slotRegistro()));
	connect(bIniciar,SIGNAL(clicked()),
		this,SLOT(slotIniciar()));
	connect(bInvitado,SIGNAL(clicked()),
		this,SLOT(slotInvitado()));
}


void DLogin::slotEjemplo(){

}

void DLogin::slotRegistro(){
	if (dRegistro == NULL)
		dRegistro = new DRegistro();
	dRegistro->show();
	this->close();
}

void DLogin::slotIniciar(){
	
	if (mainWindow == NULL)
		mainWindow = new MainWindow();
	mainWindow->show();
	this->close();
}

void DLogin::slotInvitado(){
	if (mainWindow == NULL)
		mainWindow = new MainWindow();
	mainWindow->show();
	this->close();
}
