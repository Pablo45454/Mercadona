/********************************************************************************
** Form generated from reading UI file 'dprincipal.ui'
**
** Created by: Qt User Interface Compiler version 5.15.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DPRINCIPAL_H
#define UI_DPRINCIPAL_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_DPrincipal
{
public:
    QLabel *nombreSesion;
    QTabWidget *tabProductos;
    QWidget *tab;
    QWidget *tab_2;

    void setupUi(QDialog *DPrincipal)
    {
        if (DPrincipal->objectName().isEmpty())
            DPrincipal->setObjectName(QString::fromUtf8("DPrincipal"));
        DPrincipal->resize(910, 486);
        nombreSesion = new QLabel(DPrincipal);
        nombreSesion->setObjectName(QString::fromUtf8("nombreSesion"));
        nombreSesion->setGeometry(QRect(520, 20, 351, 21));
        tabProductos = new QTabWidget(DPrincipal);
        tabProductos->setObjectName(QString::fromUtf8("tabProductos"));
        tabProductos->setGeometry(QRect(30, 60, 851, 361));
        tab = new QWidget();
        tab->setObjectName(QString::fromUtf8("tab"));
        tabProductos->addTab(tab, QString());
        tab_2 = new QWidget();
        tab_2->setObjectName(QString::fromUtf8("tab_2"));
        tabProductos->addTab(tab_2, QString());

        retranslateUi(DPrincipal);

        QMetaObject::connectSlotsByName(DPrincipal);
    } // setupUi

    void retranslateUi(QDialog *DPrincipal)
    {
        DPrincipal->setWindowTitle(QCoreApplication::translate("DPrincipal", "Dialog", nullptr));
        nombreSesion->setText(QCoreApplication::translate("DPrincipal", "Hola", nullptr));
        tabProductos->setTabText(tabProductos->indexOf(tab), QCoreApplication::translate("DPrincipal", "Tab 1", nullptr));
        tabProductos->setTabText(tabProductos->indexOf(tab_2), QCoreApplication::translate("DPrincipal", "Tab 2", nullptr));
    } // retranslateUi

};

namespace Ui {
    class DPrincipal: public Ui_DPrincipal {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DPRINCIPAL_H
