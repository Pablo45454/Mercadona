
#include "widgetproducto.h"
#include <QDebug>

WidgetProducto::WidgetProducto(QWidget *parent): QWidget(parent){
		setupUi(this);

	
}


void WidgetProducto::slotEjemplo(){

}

