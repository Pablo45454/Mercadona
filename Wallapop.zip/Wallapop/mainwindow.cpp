#include "mainwindow.h"
#include <QDebug>



MainWindow::MainWindow(QWidget *parent): QMainWindow(parent){
		setupUi(this);
		
	tabProductos->clear();
	dUsuarioEditar=NULL;
	modeloTablaProductos=NULL;
	tablaProductos = new QTableView();
	pController = new ProductoController();
	connect(pController,SIGNAL(peticionTerminada()),
		this,SLOT(slotPeticionProductoTerminada()));
	pController->selectAll();
	
	modeloTablaCategorias=NULL;
	tablaCategorias = new QTableView();
	cController = new CategoriaController();
	connect(cController,SIGNAL(peticionTerminada()),
		this,SLOT(slotPeticionCategoriaTerminada()));
	cController->selectAll();
	
	modeloTablaUsuarios=NULL;
	tablaUsuarios = new QTableView();
	uController = new UsuarioController();
	uController->selectAll();
	connect(uController,SIGNAL(peticionTerminada()),
		this,SLOT(slotPeticionUsuarioTerminada()));
	
	
	
	
	
}

void MainWindow::slotDialogoUsuario(const QModelIndex &index){
	int i =  index.row();
	qDebug()<<listaUsuarios.at(i)->name;
	if (dUsuarioEditar==NULL)
		dUsuarioEditar = new DUsuarioEditar(listaUsuarios.at(i));
	
	dUsuarioEditar->show();
	connect(dUsuarioEditar,SIGNAL(finished(int)),
		this,SLOT(slotDialogoUsuarioFinalizado(int)));


}


void MainWindow::slotDialogoUsuarioFinalizado(int result){
	if(result==QDialog::Accepted){
		dUsuarioEditar=NULL;
		delete dUsuarioEditar;
		qDebug()<<"se acepta el dialogo";
		uController->selectAll();
	
	}
	if(result==QDialog::Rejected){
		qDebug()<<"se reject el dialogo";
		dUsuarioEditar=NULL;
		delete dUsuarioEditar;

	}
}

void MainWindow::slotPeticionProductoTerminada(){
	
	pController->getProductos(&listaProductos);
	crearTablaProductos();


}

void MainWindow::crearTablaProductos(){

	modeloTablaProductos = new TablaProducto(&listaProductos);
	tablaProductos->setModel(modeloTablaProductos);
	
	tabProductos->addTab(tablaProductos,"Productos");
	


}



void MainWindow::slotPeticionCategoriaTerminada(){
	
	cController->getCategorias(&listaCategorias);
	crearTablaCategorias();

}

void MainWindow::crearTablaCategorias(){

	modeloTablaCategorias = new TablaCategoria(&listaCategorias);
	tablaCategorias->setModel(modeloTablaCategorias);
	
	tabProductos->addTab(tablaCategorias,"Categorias");
	
}

void MainWindow::slotPeticionUsuarioTerminada(){
	
	
		uController->getUsuarios(&listaUsuarios);
		if(modeloTablaUsuarios==NULL){
			crearTablaUsuarios();
		}
		modeloTablaUsuarios->actualizaDatos(); 
		
		
	
	
	

}

void MainWindow::crearTablaUsuarios(){
	
	modeloTablaUsuarios = new TablaUsuario(&listaUsuarios);
	tablaUsuarios->setModel(modeloTablaUsuarios);
	connect(tablaUsuarios,SIGNAL(doubleClicked(const QModelIndex &)),
			this,SLOT(slotDialogoUsuario(const QModelIndex &)));
	tabProductos->addTab(tablaUsuarios,"Usuarios");
	
	
}


