#include <QString>
#include "producto.h"

Producto::Producto()
{

}

Producto::Producto(int idPasado, QString namePasado, int pricePasado, QString descriptionPasado, QString ubicationPasado, int usuarioPasado, QString fecha_publicacionPasado, int categoriaPasado)
{

	id = idPasado;
	name = namePasado;
	price = pricePasado;
	description = descriptionPasado;
	ubication = ubicationPasado;
	usuario = usuarioPasado;
	fecha_publicacion = fecha_publicacionPasado;
	categoria = categoriaPasado;

}

/*Producto::Producto(QString namePasado, int pricePasado, QString descriptionPasado, QString ubicationPasado, int usuarioPasado, QString fecha_publicacionPasado, int categoriaPasado)
{

	name = namePasado;
	price = pricePasado;
	description = descriptionPasado;
	ubication = ubicationPasado;
	usuario = usuarioPasado;
	fecha_publicacion = fecha_publicacionPasado;
	categoria = categoriaPasado;

}*/


