#include "tablacategoria.h"

TablaCategoria::TablaCategoria(QVector <Categoria*> *listaCategoriasPasada){
	listaCategorias = listaCategoriasPasada;

}
int TablaCategoria::columnCount(const QModelIndex &)const{
	return 2;
}

int TablaCategoria::rowCount(const QModelIndex &)const{
	return listaCategorias->size();

}
QVariant TablaCategoria::data(const QModelIndex &index, int role)const{
	int row = index.row();
	int col = index.column();
	if(role ==Qt::BackgroundRole){
		
	}
	if(role !=Qt::DisplayRole) return QVariant();
	QString cadena("hola");
	switch(col){
		case 0:
			cadena=QString::number(listaCategorias->at(row)->id);
			
			break;
		case 1:
			cadena=listaCategorias->at(row)->name;
			
			break;
		
		
	
	}
	
	return QVariant(cadena);
	
	

}
QVariant TablaCategoria::headerData(int section,Qt::Orientation orientation, int role)const{
	int i = 0;
	if(role !=Qt::DisplayRole)return QVariant();
		if(orientation == Qt::Horizontal){
			switch(section){
				case 0: return QString("ID ");
				case 1: return QString("Name ");
		
			}
		}
		QString cadena("Bola ");
		if(orientation==Qt::Vertical){
		return QVariant(QString::number(section));
		
		}
		return QVariant();
}
