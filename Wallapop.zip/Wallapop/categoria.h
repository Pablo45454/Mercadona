#ifndef _CATEGORIA_H_
#define _CATEGORIA_H_

#include <QString>

class Categoria
{

public:
    Categoria();
    Categoria(int, QString);
    Categoria(QString);
  
    int id;
    QString name;
    
	
};





#endif
