/********************************************************************************
** Form generated from reading UI file 'widgetproducto.ui'
**
** Created by: Qt User Interface Compiler version 5.15.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_WIDGETPRODUCTO_H
#define UI_WIDGETPRODUCTO_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QTableView>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_WidgetProducto
{
public:
    QTableView *tablaProductos;

    void setupUi(QWidget *WidgetProducto)
    {
        if (WidgetProducto->objectName().isEmpty())
            WidgetProducto->setObjectName(QString::fromUtf8("WidgetProducto"));
        WidgetProducto->resize(763, 350);
        tablaProductos = new QTableView(WidgetProducto);
        tablaProductos->setObjectName(QString::fromUtf8("tablaProductos"));
        tablaProductos->setGeometry(QRect(30, 20, 701, 301));

        retranslateUi(WidgetProducto);

        QMetaObject::connectSlotsByName(WidgetProducto);
    } // setupUi

    void retranslateUi(QWidget *WidgetProducto)
    {
        WidgetProducto->setWindowTitle(QCoreApplication::translate("WidgetProducto", "Form", nullptr));
    } // retranslateUi

};

namespace Ui {
    class WidgetProducto: public Ui_WidgetProducto {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_WIDGETPRODUCTO_H
