/********************************************************************************
** Form generated from reading UI file 'dusuarioeditar.ui'
**
** Created by: Qt User Interface Compiler version 5.15.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DUSUARIOEDITAR_H
#define UI_DUSUARIOEDITAR_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_DUsuarioEditar
{
public:
    QWidget *widget;
    QVBoxLayout *verticalLayout_3;
    QHBoxLayout *horizontalLayout_2;
    QVBoxLayout *verticalLayout;
    QLabel *Nombre;
    QLabel *label_2;
    QLabel *label_3;
    QLabel *label_4;
    QLabel *label_5;
    QVBoxLayout *verticalLayout_2;
    QLineEdit *lName;
    QLineEdit *lUserName;
    QLineEdit *lEmail;
    QLineEdit *lPassword;
    QLineEdit *lNum;
    QHBoxLayout *horizontalLayout;
    QPushButton *bGuardar;
    QPushButton *bCancelar;
    QPushButton *bBorrar;

    void setupUi(QDialog *DUsuarioEditar)
    {
        if (DUsuarioEditar->objectName().isEmpty())
            DUsuarioEditar->setObjectName(QString::fromUtf8("DUsuarioEditar"));
        DUsuarioEditar->resize(580, 342);
        widget = new QWidget(DUsuarioEditar);
        widget->setObjectName(QString::fromUtf8("widget"));
        widget->setGeometry(QRect(160, 60, 328, 188));
        verticalLayout_3 = new QVBoxLayout(widget);
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        verticalLayout_3->setContentsMargins(0, 0, 0, 0);
        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        Nombre = new QLabel(widget);
        Nombre->setObjectName(QString::fromUtf8("Nombre"));

        verticalLayout->addWidget(Nombre);

        label_2 = new QLabel(widget);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        verticalLayout->addWidget(label_2);

        label_3 = new QLabel(widget);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        verticalLayout->addWidget(label_3);

        label_4 = new QLabel(widget);
        label_4->setObjectName(QString::fromUtf8("label_4"));

        verticalLayout->addWidget(label_4);

        label_5 = new QLabel(widget);
        label_5->setObjectName(QString::fromUtf8("label_5"));

        verticalLayout->addWidget(label_5);


        horizontalLayout_2->addLayout(verticalLayout);

        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        lName = new QLineEdit(widget);
        lName->setObjectName(QString::fromUtf8("lName"));

        verticalLayout_2->addWidget(lName);

        lUserName = new QLineEdit(widget);
        lUserName->setObjectName(QString::fromUtf8("lUserName"));

        verticalLayout_2->addWidget(lUserName);

        lEmail = new QLineEdit(widget);
        lEmail->setObjectName(QString::fromUtf8("lEmail"));

        verticalLayout_2->addWidget(lEmail);

        lPassword = new QLineEdit(widget);
        lPassword->setObjectName(QString::fromUtf8("lPassword"));

        verticalLayout_2->addWidget(lPassword);

        lNum = new QLineEdit(widget);
        lNum->setObjectName(QString::fromUtf8("lNum"));

        verticalLayout_2->addWidget(lNum);


        horizontalLayout_2->addLayout(verticalLayout_2);


        verticalLayout_3->addLayout(horizontalLayout_2);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        bGuardar = new QPushButton(widget);
        bGuardar->setObjectName(QString::fromUtf8("bGuardar"));

        horizontalLayout->addWidget(bGuardar);

        bCancelar = new QPushButton(widget);
        bCancelar->setObjectName(QString::fromUtf8("bCancelar"));

        horizontalLayout->addWidget(bCancelar);

        bBorrar = new QPushButton(widget);
        bBorrar->setObjectName(QString::fromUtf8("bBorrar"));

        horizontalLayout->addWidget(bBorrar);


        verticalLayout_3->addLayout(horizontalLayout);


        retranslateUi(DUsuarioEditar);

        QMetaObject::connectSlotsByName(DUsuarioEditar);
    } // setupUi

    void retranslateUi(QDialog *DUsuarioEditar)
    {
        DUsuarioEditar->setWindowTitle(QCoreApplication::translate("DUsuarioEditar", "Dialog", nullptr));
        Nombre->setText(QCoreApplication::translate("DUsuarioEditar", "Name", nullptr));
        label_2->setText(QCoreApplication::translate("DUsuarioEditar", "User Name", nullptr));
        label_3->setText(QCoreApplication::translate("DUsuarioEditar", "Email", nullptr));
        label_4->setText(QCoreApplication::translate("DUsuarioEditar", "Password", nullptr));
        label_5->setText(QCoreApplication::translate("DUsuarioEditar", "Num. tel.", nullptr));
        bGuardar->setText(QCoreApplication::translate("DUsuarioEditar", "Guardar Cambios", nullptr));
        bCancelar->setText(QCoreApplication::translate("DUsuarioEditar", "Cancelar", nullptr));
        bBorrar->setText(QCoreApplication::translate("DUsuarioEditar", "Borrar Usuario", nullptr));
    } // retranslateUi

};

namespace Ui {
    class DUsuarioEditar: public Ui_DUsuarioEditar {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DUSUARIOEDITAR_H
