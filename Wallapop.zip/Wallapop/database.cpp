#include "database.h"
#include <QVariant>

Database::Database()
{

}



bool Database::connect()
{
	db = QSqlDatabase::addDatabase("QPSQL");
	db.setHostName("192.168.8.14");
	db.setDatabaseName("salespop2");
	db.setUserName("postgres");
	db.setPassword("");
	
	if(!db.open()) {
		qDebug()<<"No se puedo conectar";
		return false;
	}
	
	return true;
}

void Database::close()
{
	db.close();
}

bool Database::insert()
{
	QSqlQuery query;
	
	return query.exec();	
}

bool Database::update()
{
		
}

bool Database::remove()
{
	QSqlQuery query;
	
	
	return query.exec();	
}
void Database::selectAll(){
	QSqlQuery query;
	
	query.exec();
	
	while(query.next()){
		QString cadena = query.value(0).toString();
         qDebug()<<cadena;
         
	}
	qDebug()<<query.size();
	
	query.exec();	
	
	


}

