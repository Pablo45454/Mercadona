
#include "dusuarioeditar.h"
#include <QDebug>

DUsuarioEditar::DUsuarioEditar(QWidget *parent): QDialog(parent){
		setupUi(this);

	
}

DUsuarioEditar::DUsuarioEditar(Usuario *usuarioPasado,QWidget *parent): QDialog(parent){
		setupUi(this);
	uController = new UsuarioController();
	usuario = usuarioPasado;
	lName->insert(usuario->name);
	lEmail->insert(usuario->mail);
	lUserName->insert(usuario->user_name);
	lPassword->insert(usuario->password);
	lNum->insert(usuario->num_tel);
	connect(bBorrar,SIGNAL(clicked()),
			this,SLOT(slotBorrarUsuario()));
	connect(bCancelar,SIGNAL(clicked()),
			this,SLOT(slotCancelarDialogo()));
	connect(bGuardar,SIGNAL(clicked()),
			this,SLOT(slotGuardarUsuario()));
	connect(uController,SIGNAL(peticionTerminada()),
			this,SLOT(slotEmitirAccept()));
}

void DUsuarioEditar::slotCancelarDialogo(){

	this->reject();


}
void DUsuarioEditar::closeEvent(QCloseEvent *event)
{

       this->reject();
    
}

void DUsuarioEditar::slotEmitirAccept(){
	
		this->accept();
}


void DUsuarioEditar::slotBorrarUsuario(){
	
	int respuesta = QMessageBox::warning(this,QString("Esta seguro que quieres borrar?"),
	QString("¿Seguro?"),
	QMessageBox::Yes | QMessageBox::No);
	if (respuesta == QMessageBox::No) qDebug()<<"no se acepto el dialogo";
	if(respuesta == QMessageBox::Yes){
	
		uController->eliminarUsuario(usuario->id);
		
	
	}
}

void DUsuarioEditar::slotGuardarUsuario(){
	
	int respuesta = QMessageBox::warning(this,QString("Esta seguro que quieres guardar?"),
	QString("¿Seguro?"),
	QMessageBox::Yes | QMessageBox::No);
	if (respuesta == QMessageBox::No) qDebug()<<"no se acepto el dialogo";
	if(respuesta == QMessageBox::Yes){
		usuario->name=lName->displayText();
		usuario->mail=lEmail->displayText();
		usuario->user_name=lUserName->displayText();
		usuario->password=lPassword->displayText();
		usuario->num_tel=lNum->displayText();
		
		uController->editarUsuario(usuario);
		
		
	
	}


}




