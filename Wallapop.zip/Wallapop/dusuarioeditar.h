
#ifndef DUSUARIOEDITAR_H
#define DUSUARIOEDITAR_H
#include "ui_dusuarioeditar.h"

#include <QVector>
#include <QDialog>
#include <QHBoxLayout>
#include "usuario.h"
#include "usuariocontroller.h"
#include <QMessageBox>
class DUsuarioEditar : public QDialog, public Ui::DUsuarioEditar {
Q_OBJECT

public:
	DUsuarioEditar(QWidget *parent = NULL);
	DUsuarioEditar(Usuario *, QWidget *parent = NULL);
	Usuario *usuario;
	UsuarioController *uController;
	void closeEvent(QCloseEvent *);

public slots:
	void slotBorrarUsuario();
	void slotCancelarDialogo();
	void slotGuardarUsuario();
	void slotEmitirAccept();
};

#endif 
