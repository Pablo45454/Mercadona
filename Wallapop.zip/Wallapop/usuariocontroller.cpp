#include "usuariocontroller.h"

UsuarioController::UsuarioController()
{

}

void UsuarioController::selectAll(){
qDebug()<<"Llego a selectall";
	QJsonObject jsonObject;
	jsonObject.insert("jsonrpc", "2.0");
        jsonObject.insert("method", "call");
        jsonObject.insert("id", 970248153);
        QJsonObject params;
        params.insert("service", "object");
        params.insert("method", "execute");
        QJsonArray args;
        args.append("salespop");
        args.append(2);
        args.append("1234");
        args.append("res.partner");
        args.append("search_read");
        QJsonArray emptyArray;
        args.append(emptyArray);
        QJsonArray fields;
        fields.append("id");
        fields.append("name"); 
        fields.append("user_name");
        fields.append("num_tel");
        fields.append("password");
        fields.append("mail");
        args.append(fields);
        params.insert("args", args);
        jsonObject.insert("params", params);
        
        QByteArray postData = QJsonDocument(jsonObject).toJson();
	QNetworkAccessManager *manager = new QNetworkAccessManager();
	connect(manager,SIGNAL(finished(QNetworkReply *)),
		this,SLOT(slotPeticion(QNetworkReply *)));
	QNetworkRequest request;
	request.setUrl(QUrl("http://192.168.8.13:8069/jsonrpc"));
	request.setRawHeader(QByteArray("Content-Type"), QByteArray("application/json"));
	QNetworkReply *reply = manager->post(request, postData);
	
	



}
void UsuarioController::slotPeticion(QNetworkReply* reply){
 if (reply->error() != QNetworkReply::NoError) {
            qDebug() << "Error: " << reply->errorString();
        } else  if (reply->isFinished()){
        	
            responseData =QJsonDocument::fromJson(reply->readAll());
            
            emit peticionTerminada();
            
               
        }
        reply->deleteLater();

}

void UsuarioController::getUsuarios(QVector<Usuario*> *listaUsuarios){
		for(int i = 0; i<listaUsuarios->size();i++){
			delete listaUsuarios->at(i);
		
		}
		listaUsuarios->clear();
		qDebug()<<"tamaño despues del clear:"<<listaUsuarios->size();
 		QJsonObject jsonResponse = responseData.object();
            
            if(jsonResponse.contains("result")){
            	QJsonArray result = jsonResponse["result"].toArray();
            	qDebug()<<"result size:"<<result.size();
            	for(int i = 0; i < result.size(); i++){
            		QJsonObject partner = result[i].toObject();
            		Usuario *usuario = new Usuario(partner["id"].toInt(),
            		partner["name"].toString(),
            		partner["user_name"].toString(),
            		partner["num_tel"].toString(),
            		partner["password"].toString(),
            		partner["mail"].toString());
            		listaUsuarios->append(usuario);
            	}
            	qDebug()<<"tamaño despues de la peticion"<<listaUsuarios->size();
            	
            
            }


}

void UsuarioController::eliminarUsuario(int id){
	QJsonObject jsonObject;
	jsonObject.insert("jsonrpc", "2.0");
        jsonObject.insert("method", "call");
        jsonObject.insert("id", 970248153);
        QJsonObject params;
        params.insert("service", "object");
        params.insert("method", "execute");
        QJsonArray args;
        args.append("salespop");
        args.append(2);
        args.append("1234");
        args.append("res.partner");
        args.append("unlink");
        QJsonArray idArray;
        idArray.append(id);
        args.append(idArray);
        params.insert("args", args);
        jsonObject.insert("params", params);
        
        QByteArray postData = QJsonDocument(jsonObject).toJson();
	QNetworkAccessManager *manager = new QNetworkAccessManager();
	connect(manager,SIGNAL(finished(QNetworkReply *)),
		this,SLOT(slotPeticion(QNetworkReply *)));
	QNetworkRequest request;
	request.setUrl(QUrl("http://192.168.8.13:8069/jsonrpc"));
	request.setRawHeader(QByteArray("Content-Type"), QByteArray("application/json"));
	QNetworkReply *reply = manager->post(request, postData);
	if (reply->error() != QNetworkReply::NoError) {
            qDebug() << "Error: " << reply->errorString();
        } else {
        
        qDebug() << reply->readAll();
        }



}

void UsuarioController::editarUsuario(Usuario *usuario){
	QJsonObject jsonObject;
	jsonObject.insert("jsonrpc", "2.0");
        jsonObject.insert("method", "call");
        jsonObject.insert("id", 970248153);
        QJsonObject params;
        params.insert("service", "object");
        params.insert("method", "execute");
        QJsonArray args;
        args.append("salespop");
        args.append(2);
        args.append("1234");
        args.append("res.partner");
        args.append("write");
        
        QJsonObject fields;
     
     	QJsonArray idArray;
     	
        idArray.append(usuario->id);
        fields.insert("name",usuario->name);
        fields.insert("user_name",usuario->user_name);
        fields.insert("num_tel",usuario->num_tel);
        fields.insert("password",usuario->password);
        fields.insert("mail",usuario->mail);
        
        args.append(idArray);
        args.append(fields);
        params.insert("args", args);
        jsonObject.insert("params", params);
        
        QByteArray postData = QJsonDocument(jsonObject).toJson();
	QNetworkAccessManager *manager = new QNetworkAccessManager();
	connect(manager,SIGNAL(finished(QNetworkReply *)),
		this,SLOT(slotPeticion(QNetworkReply *)));
	QNetworkRequest request;
	request.setUrl(QUrl("http://192.168.8.13:8069/jsonrpc"));
	request.setRawHeader(QByteArray("Content-Type"), QByteArray("application/json"));
	QNetworkReply *reply = manager->post(request, postData);
	if (reply->error() != QNetworkReply::NoError) {
            qDebug() << "Error: " << reply->errorString();
        } else {
        
        qDebug() << reply->readAll();
        }





}


