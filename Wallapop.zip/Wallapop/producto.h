#ifndef _PRODUCTO_H_
#define _PRODUCTO_H_
#include <QString>
#include "usuario.h"

class Producto
{

public:
    Producto();
    Producto(int, QString, int, QString, QString, int , QString, int);
    //Producto(QString, int, QString, QString, int , QString, int);
    int id;
    QString name;
    int price;
    QString description;
    QString ubication;
    int usuario;
    QString fecha_publicacion;
    int categoria;
};




#endif
