
#ifndef WIDGETPRODUCTO_H
#define WIDGETPRODUCTO_H
#include "ui_widgetproducto.h"

#include <QVector>
#include <QWidget>
#include <QHBoxLayout>

class WidgetProducto : public QWidget, public Ui::WidgetProducto {
Q_OBJECT

public:
	WidgetProducto(QWidget *parent = NULL);

public slots:
	void slotEjemplo();

};

#endif 
