#include <QString>
#include "usuario.h"

Usuario::Usuario(){
	name = "Pablo";
   	 
}

Usuario::Usuario(int idPasado, QString namePasado, QString user_namePasado, QString num_telPasado, QString passwordPasado, QString mailPasado)
{
	id = idPasado;
	name = namePasado;
	user_name = user_namePasado;
	num_tel = num_telPasado;
	password = passwordPasado;
	mail = mailPasado;
}

Usuario::Usuario(QString namePasado, QString user_namePasado, QString num_telPasado, QString passwordPasado, QString mailPasado)
{
	name = namePasado;
	user_name = user_namePasado;
	num_tel = num_telPasado;
	password = passwordPasado;
	mail = mailPasado;
}


