#ifndef _USUARIO_H_
#define _USUARIO_H_

#include <QString>
#include "producto.h"

class Usuario
{

public:
    Usuario();
    Usuario(int, QString, QString, QString, QString, QString);
    Usuario(QString, QString, QString, QString, QString);
    
    QString num_tel;
    QString name;
    QString user_name;
    int id;
    QString mail;
    QString password;
    
	
};





#endif
