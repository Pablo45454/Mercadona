#include "tablaproducto.h"

TablaProducto::TablaProducto(QVector <Producto*> *listaProductosPasada){
	listaProductos = listaProductosPasada;

}
int TablaProducto::columnCount(const QModelIndex &)const{
	return 8;
}

int TablaProducto::rowCount(const QModelIndex &)const{
	return listaProductos->size();

}
QVariant TablaProducto::data(const QModelIndex &index, int role)const{
	int row = index.row();
	int col = index.column();
	if(role ==Qt::BackgroundRole){
		
	}
	if(role !=Qt::DisplayRole) return QVariant();
	QString cadena("hola");
	switch(col){
		case 0:
			cadena=QString::number(listaProductos->at(row)->id);
			
			break;
		case 1:
			cadena=listaProductos->at(row)->name;
			
			break;
		case 2:
			cadena=QString::number(listaProductos->at(row)->categoria);
			
			break;
		case 3:
			cadena=QString::number(listaProductos->at(row)->price);
			
			break;
		case 4:
			cadena=listaProductos->at(row)->description;
			
			break;
		case 5:
			cadena=listaProductos->at(row)->ubication;
			
			break;
		case 6:
			cadena=QString::number(listaProductos->at(row)->usuario);
			
			break;
		case 7:
			cadena=listaProductos->at(row)->fecha_publicacion;
			
			break;
	
	}
	
	return QVariant(cadena);
	
	

}
QVariant TablaProducto::headerData(int section,Qt::Orientation orientation, int role)const{
	int i = 0;
	if(role !=Qt::DisplayRole)return QVariant();
		if(orientation == Qt::Horizontal){
			switch(section){
				case 0: return QString("ID ");
				case 1: return QString("Name ");
				case 2: return QString("Categoria ");
				case 3: return QString("Precio ");
				case 4: return QString("Descripcion ");
				case 5: return QString("Ubicacion ");
				case 6: return QString("Usuario ");
				case 7: return QString("Fecha ");
				
			}
		}
		QString cadena("Bola ");
		if(orientation==Qt::Vertical){
		return QVariant(QString::number(section));
		
		}
		return QVariant();
}

void TablaProducto::actualizaDatos(){
	
	emit layoutChanged();


}

