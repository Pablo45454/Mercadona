#ifndef _PRODUCTOCONTROLLER_H_
#define _PRODUCTOCONTROLLER_H_
#include <QString>
#include "producto.h"
#include <QtNetwork>
#include <QtNetwork/QNetworkRequest>
#include <QtNetwork/QNetworkReply>
#include <QtNetwork/QNetworkAccessManager>
#include <QByteArray>
#include <QJsonObject>
#include <QJsonArray>
#include <QJsonDocument>
#include <QVector>

class ProductoController : public QObject{
Q_OBJECT

public:
	ProductoController();
	void selectAll();
	void getProductos(QVector<Producto*> *);
	
	QJsonDocument responseData;
	
public slots:

	void slotPeticion(QNetworkReply*);
signals:
    	void peticionTerminada();
	
	

};

#endif
