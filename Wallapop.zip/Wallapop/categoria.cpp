#include <QString>
#include "categoria.h"


Categoria::Categoria(){
	
   	 
}

Categoria::Categoria(int idPasado, QString namePasado)
{
	id = idPasado;
	name = namePasado;
	
}

Categoria::Categoria(QString namePasado)
{
	name = namePasado;
	
}
