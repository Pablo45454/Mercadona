#ifndef _CATEGORIACONTROLLER_H_
#define _CATEGORIACONTROLLER_H_
#include <QString>
#include "categoria.h"
#include <QtNetwork>
#include <QtNetwork/QNetworkRequest>
#include <QtNetwork/QNetworkReply>
#include <QtNetwork/QNetworkAccessManager>
#include <QByteArray>
#include <QJsonObject>
#include <QJsonArray>
#include <QJsonDocument>
#include <QVector>

class CategoriaController : public QObject{
Q_OBJECT

public:
	CategoriaController();
	void selectAll();
	void getCategorias(QVector<Categoria*> *);
	/*void editarArticulo(Articulo *);
	void eliminarArticulo(int);
	void insertarArticulo(Articulo *);*/
	QJsonDocument responseData;
	
public slots:

	void slotPeticion(QNetworkReply*);
signals:
    	void peticionTerminada();
	
	

};

#endif
