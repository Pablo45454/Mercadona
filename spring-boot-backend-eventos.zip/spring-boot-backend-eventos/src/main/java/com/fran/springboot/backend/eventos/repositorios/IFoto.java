package com.fran.springboot.backend.eventos.repositorios;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.fran.springboot.backend.eventos.entidades.Foto;
import com.fran.springboot.backend.eventos.entidades.Product;

@Repository
public interface IFoto extends JpaRepository<Foto,Integer>{
	@Query("FROM Foto f WHERE (f.name) = :name")
	Foto listarPorName(@Param("name") String name);
}
